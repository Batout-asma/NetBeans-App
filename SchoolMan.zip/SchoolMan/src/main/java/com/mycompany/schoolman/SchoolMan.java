/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.schoolman;

/**
 *
 * @author Batout
 */
public class SchoolMan {

    public static void main(String[] args) {
        System.out.println("Our app is being started...");
        new Login().show();
        System.out.println("Started.");

    }
}
